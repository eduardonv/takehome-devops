#/bin/sh

USERINFO_URL=http://auth-service:8037/api/userinfo npm run start
