# Feed

Simple feed service. Depends on the auth server's userinfo API.

How to run:
- npm install
- npm run release
- USERINFO_URL=http://localhost:8037/api/userinfo npm run start
