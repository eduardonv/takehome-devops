# Auth

Simple authentication service.
- Tokens are stored at `resources/userinfo.json`
- Server config is stored at `resources/config.json`

How to run the project
- pipenv install
- pipenv run python src/server.py
